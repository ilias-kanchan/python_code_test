from appb import Worker
import json
import shutil
import os
from datetime import datetime

date = datetime.now().strftime("%Y_%m_%d-%I:%M:%S_%p")
backup_file_name = f"access_points_{date}"
shutil.copyfile("/tmp/access_points.json", f"./backup/{backup_file_name}.json")

myfile = "./old_access_points.json"
if not os.path.isfile(myfile):
    shutil.copyfile("/tmp/access_points.json", "old_access_points.json")

f = open('/tmp/access_points.json')
data = json.load(f)

for keys, values in data.items():
    for i in range(len(values)):
        current_ssid = values[i]["ssid"]
        current_snr = values[i]["snr"]
        current_channel = values[i]["channel"]

        check_data = Worker(current_ssid, current_snr, current_channel)
        check_data.check_change()
        check_data.check_new_ssid()

f.close()

check_data.check_deleted_ssid()

myfile = "./old_access_points.json"
if os.path.isfile(myfile):
    os.remove(myfile)
shutil.copyfile("/tmp/access_points.json", "old_access_points.json")
