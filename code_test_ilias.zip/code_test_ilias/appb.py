import datetime
import json


class Worker:

    def __init__(self, current_ssid, current_snr, current_channel):
        self.current_ssid = current_ssid
        self.current_snr = current_snr
        self.current_channel = current_channel

    def check_change(self):
        current_ssid = self.current_ssid
        current_snr = self.current_snr
        current_channel = self.current_channel

        f2 = open('old_access_points.json')
        old_data = json.load(f2)
        for old_keys, old_values in old_data.items():
            for j in range(len(old_values)):
                old_ssid = old_values[j]["ssid"]
                old_snr = old_values[j]["snr"]
                old_channel = old_values[j]["channel"]
                if old_ssid == current_ssid:
                    if old_snr != current_snr:
                        print(f"{old_ssid}'s SNR has changed from {old_snr} to {current_snr}")
                        with open(f"log.txt", "a+") as f:
                            x = datetime.datetime.now()
                            today_date_time = x.strftime("%Y_%m_%d_%H_%M_%S_yyyy_mm_dd_hr_min_sec")
                            f.write(f"Date time {today_date_time} {old_ssid}'s SNR has changed from {old_snr} to {current_snr}\n")

                    elif old_channel != current_channel:
                        print(f"{old_ssid}'s channel has changed from {old_channel} to {current_channel}")
                        with open(f"log.txt", "a+") as f:
                            x = datetime.datetime.now()
                            today_date_time = x.strftime("%Y_%m_%d_%H_%M_%S_yyyy_mm_dd_hr_min_sec")
                            f.write(f"Date time {today_date_time} {old_ssid}'s channel has changed from {old_channel} to {current_channel}\n")
        f2.close()

    def check_new_ssid(self):
        current_ssid = self.current_ssid
        current_snr = self.current_snr
        current_channel = self.current_channel

        f2 = open('old_access_points.json')
        old_data = json.load(f2)
        for old_keys, old_values in old_data.items():
            all_old_ssid = []
            for j in range(len(old_values)):
                all_old_ssid.append(old_values[j]["ssid"])

            if current_ssid not in all_old_ssid:
                print(f"{current_ssid} is added to the list with SNR {current_snr} and channel {current_channel}")
                with open(f"log.txt", "a+") as f:
                    x = datetime.datetime.now()
                    today_date_time = x.strftime("%Y_%m_%d_%H_%M_%S_yyyy_mm_dd_hr_min_sec")
                    f.write(
                        f"Date time {today_date_time} {current_ssid} is added to the list with SNR {current_snr} and channel {current_channel}\n")
        f2.close()

    def check_deleted_ssid(self):
        current_ssid = self.current_ssid
        current_snr = self.current_snr
        current_channel = self.current_channel

        f2 = open('old_access_points.json')
        old_data = json.load(f2)

        for old_keys, old_values in old_data.items():
            for j in range(len(old_values)):
                old_ssid = old_values[j]["ssid"]
                old_snr = old_values[j]["snr"]
                old_channel = old_values[j]["channel"]
                f1 = open('/tmp/access_points.json')
                new_data = json.load(f1)
                for new_keys, new_values in new_data.items():
                    all_new_ssid = []
                    for i in range(len(new_values)):
                        all_new_ssid.append(new_values[i]["ssid"])
                    if old_ssid not in all_new_ssid:
                        print(f"{old_ssid} has been removed from the list with SNR {old_snr} and channel {old_channel} ")
                        with open(f"log.txt", "a+") as f:
                            x = datetime.datetime.now()
                            today_date_time = x.strftime("%Y_%m_%d_%H_%M_%S_yyyy_mm_dd_hr_min_sec")
                            f.write(f"Date time {today_date_time} {old_ssid} has been removed from the list with SNR {old_snr} and channel {old_channel}\n")
                f1.close()
        f2.close()


